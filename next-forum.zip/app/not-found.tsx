export default function NotFound() {
  return <h4>여기 아니야 돌아가.</h4>;
}
